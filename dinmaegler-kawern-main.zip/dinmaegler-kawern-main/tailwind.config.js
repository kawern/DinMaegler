// tailwind.config.js
const colors = require('tailwindcss/colors')
0
module.exports = {
  purge: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  darkMode: false, // or 'media' or 'class'
  theme: {
    fontFamily: {
      std: ['Roboto', 'sans-serif'],
    },
    colors: {
      primary: '#162A41',
      black: colors.black,
      blue: colors.blue,
      white: colors.white,
      gray: colors.trueGray,
      green: colors.green,
      indigo: colors.indigo,
      red: colors.rose,
      yellow: colors.amber,
      amber: colors.amber,
      footer: '#F8F8FB',
      lightBlue: '#EEF7FF',
      hr: '#D3DEE8',
    },
    extend: {
      backgroundImage: {
        'hero': "url('../src/images/hero.jpg')",
        'newsletter': "url('../src/images/newsletter.jpg')",
        'properties': "url('../src/images/properties.svg')"
        
       },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
