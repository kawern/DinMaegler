Projektdokumentation
Navn: Kasper Lisberg
Hold: 1146521c105 / WU05
Uddannelse: Webudvikler
Uddannelsessted: Roskilde Tekniske Skole
[https://dinmaegler-kawern.netlify.app/](https://dinmaegler-kawern.netlify.app/ "Min app")

Teknologi-stack
HTML
CSS (Tailwind)
JavaScript
React
...
**Redegørelse for oprindelsen af evt. tredjeparts kode anvendt i opgaveløsningen (Teknisk dokumentation)
(Hvilke npm-pakker har du installeret for at dit projekt virker? Beskriv kort hvilket "problem" hver pakke løser.)**

Tailwind - Som i virkeligheden bliver prefixet af craco, men det er installeret dog ikke synlig i package

@brainhubeu/react-carousel:
React carousel til billedegalleriet

@craco/craco:
Create React App Configuration Override
Tailwind prefixer

@reach/router - navigering mellem sider og links

@axios: fetch bare smartere, hvor jeg også har lavet et custom hook.

react-icons - giver mulighed for at importere (og bruge) ikoner ligesom med fx. Fontawesome, bare bedre.

react-helmet:
Giver mulighed for at ændre page titles



**Argumentation for de valg du selvstændigt har truffet under løsningen af opgaven
(Hvilke overvejelser har du gjort dig, fx. i forbindelse med dit valg af animationer)**

Jeg har valgt at bruge en npm pakke til carousellen, da det ikke lykkedes mig at lave en funktionel en med tailwind.



**Vurdering af egen indsats & gennemførelse af opgaveforløbet (Arbejdsgangen)
(Hvad gik godt. Hvor prioriterede du forkert. Klagesange fra de varme lande om halvfærdigt produkt, på grund af manglende nattesøvn, fordi din kæle-skildpadde havde tandpine er IKKE interessante.)**

Jeg synes faktisk at det her har været mit mest strukturerede projekt til dato. Jeg har endelig fået styr på min mappestruktur (views, components m.m), så alt i alt synes jeg at det er gået rigtig godt.

Der er dog enkelte funktionelle ting som jeg ikke har formået at få til at virke, men udover det er jeg tilfreds med min præstation og mit arbejde.

**_En beskrivelse af særlige punkter til bedømmelse
(er der en særlig detalje som du synes din underviser bør lægge mærke til når dit projekt evalueres)_**

Ikke rigtig, jeg fik faktisk endelig mere styr på useState, hvilket fik mig til at tvivle på min egen intelligens, da det jo faktisk er lige til...
