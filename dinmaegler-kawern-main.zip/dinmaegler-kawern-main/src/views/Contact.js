import Contactform from "../components/contact/ContactForm";
import Heading from "../components/Heading";
import ContactInfo from "../components/contact/ContactInfo";
import ContactMap from '../components/contact/ContactMap'
import { Helmet } from "react-helmet";

const Contact = () => {
    
    return (
    <section className="mb-20">
                <Helmet><title>Kontakt os - Din Mægler</title></Helmet>
                        <Heading title="Kontakt os"/>

                        <div className="flex flex-col md:flex-row md:mx-64 justify-between mb-10 gap-6">

<div className="border border-gray-200 p-8 md:w-2/3 mx-6 md:mx-0">
                            <Contactform/></div>
                            <div className="border border-gray-200 mx-6 md:mx-0 md:w-1/3">   
                            <ContactInfo/>                     
                                </div>
                        </div>
                        <div className="mx-6 md:mx-0">
                        <ContactMap/></div>
    </section>
    
    );
}
 
export default Contact;