import PropertyDetails from "../components/listings/PropertyDetails";

const ListingDetails = () => {

    return (<section className="">
<PropertyDetails/></section>
     );
}
 
export default ListingDetails;