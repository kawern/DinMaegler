import AgentInfo from "../components/agents/AgentInfo";

const AgentDetails = (props) => {

    return (<>
    
    <AgentInfo/></>);
}
 
export default AgentDetails;