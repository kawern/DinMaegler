import Heading from "../components/Heading";
import AgentList from "../components/agents/AgentList"
import { Helmet } from "react-helmet";

const Agents = () => {
    return ( <>
            <Helmet><title>Vores Mæglere - Din Mægler</title></Helmet>
                <Heading title="Medarbejdere i Roskilde"/>
                <section className="mx-6 md:mx-64 mb-20">
        <div className="flex flex-col mb-20">

<div className="">
            <AgentList endpoint=""/>
            </div>
            </div>
            </section>
            </>
     );
}
 
export default Agents;