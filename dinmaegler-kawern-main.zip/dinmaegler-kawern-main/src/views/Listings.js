import { Helmet } from "react-helmet";
import Heading from "../components/Heading";
import PropertyList from "../components/listings/PropertyList";


const Listings = (props) => {

    return (<>
    <Helmet><title>Boliger til salg - Din Mægler</title></Helmet>
        <Heading className="mx-0" title="Boliger til salg"/>
        <section className="md:mx-64 mx-6 mb-20">
        <div className="flex flex-col justify-center text-center">

            <PropertyList/>
            
            </div></section>
            </>
     );
}
 
export default Listings;