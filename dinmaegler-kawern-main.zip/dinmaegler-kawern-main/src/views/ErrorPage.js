import { Helmet } from "react-helmet";


const ErrorPage = () => {
    return ( 
        <section className="flex flex-col mx-64">
                    <Helmet><title>404 - Din Mægler</title></Helmet>
            <h1 className="4xl">404</h1>
        </section>
     );
}
 
export default ErrorPage;