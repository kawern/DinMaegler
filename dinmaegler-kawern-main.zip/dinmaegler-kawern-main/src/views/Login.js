import { TokenContext } from "../contexts/TokenContext";
import { useContext } from "react";
import { Redirect } from "@reach/router"


import LoginForm from "../components/user/LoginForm";
import { Helmet } from "react-helmet";


const Login = () => {

    const { token } = useContext(TokenContext)

    return token ? (<Redirect to="/favorites"/>) : ( <section className="md:mx-64 mb-20">
                <Helmet><title>Log ind - Din Mægler</title></Helmet>
    <LoginForm/></section> );
}
 
export default Login;