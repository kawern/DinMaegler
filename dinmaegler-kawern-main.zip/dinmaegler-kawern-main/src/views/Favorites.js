import FavoriteList from "../components/favorites/FavoriteList";
import { useContext } from "react";
import { TokenContext } from "../contexts/TokenContext";
import ErrorPage from "./ErrorPage";
import Heading from "../components/Heading";
import { Helmet } from "react-helmet";

const Favorites = (props) => {
  const { token } = useContext(TokenContext);

  return token ? (
    <>
            <Helmet><title>Mine Favoritter - Din Mægler</title></Helmet>
            <Heading className="mx-0" title="Mine Favoritboliger"/>
    <section className="md:mx-64 mb-20">
    <div className="flex flex-col gap-6">
     <FavoriteList/>
    </div>
    </section>
    </>
  ) : <ErrorPage/>
};

export default Favorites;
