import useAxios from "../customhooks/useAxios";
import NumberFormat from "react-number-format";
import { TokenContext } from "../contexts/TokenContext";
import { useContext } from "react";
import CardSkeleton from "../components/CardSkeleton";
import { VscHome } from 'react-icons/all'



const Test = () => {

    const url = `https://dinmaegler.herokuapp.com/homes`
    const { data, loading } = useAxios(url);

    const { token } = useContext(TokenContext)

    return loading ? <CardSkeleton/> : ( 
        <>
        {data?.map(homes => (
        <div className="max-w-md w-full sm:w-1/2 py-6 px-3">
        <div className="bg-white shadow-xl rounded-lg overflow-hidden">
            <div className="bg-cover bg-center h-56 p-4"
            style={ {backgroundImage: `url(${homes.images[0].url})`}}>
                                <div className="flex justify-between">
                                <span className={`text-md w-7 h-7 font-bold inline-block p-2 leading-3 text-white
              uppercase mr-4
              ${homes.energylabel === "A" ? "bg-green-600" : ""}
              ${homes.energylabel === "B" ? "bg-yellow-300" : ""}
              ${homes.energylabel === "C" ? "bg-yellow-500" : ""}
              ${homes.energylabel === "D" ? "bg-red-600" : ""}
              `}
              >
                {homes.energylabel}
              </span>
                    { token ? <svg className="h-6 w-6 text-white fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M12.76 3.76a6 6 0 0 1 8.48 8.48l-8.53 8.54a1 1 0 0 1-1.42 0l-8.53-8.54a6 6 0 0 1 8.48-8.48l.76.75.76-.75zm7.07 7.07a4 4 0 1 0-5.66-5.66l-1.46 1.47a1 1 0 0 1-1.42 0L9.83 5.17a4 4 0 1 0-5.66 5.66L12 18.66l7.83-7.83z"></path>
                    </svg> : null}
                </div>
            </div>
            <div className="p-4">
                <p className="uppercase tracking-wide text-sm font-bold text-gray-700">{homes.type} • {homes.livingspace} m²</p>
                <p className="text-3xl text-gray-900">              <NumberFormat
        value={homes.price}
        displayType={"text"}
        thousandSeparator="."
        decimalSeparator=","
        prefix={"Kr. "}
      /></p>
                <p className="text-gray-700">{homes.adress1}</p>
                <p className="text-gray-700">{homes.postalcode} {homes.city}</p>
            </div>
            <div className="flex p-4 border-t border-gray-300 text-gray-700">
                <div className="flex-1 inline-flex items-center">
                    <p><span className="text-gray-900 font-bold">Ejerudgift: {homes.cost} kr.</span></p>
                </div>
                <div className="flex-1 inline-flex items-center">
<VscHome size={24} className="mr-2"/>
                    <p><span className="text-gray-900 font-bold">{homes.rooms}</span> Værelser</p>
                </div>
            </div>
            <div className="px-4 pt-3 pb-4 border-t border-gray-300 bg-gray-100">
                <div className="text-xs uppercase font-bold text-gray-600 tracking-wide">Ansvarlig Mægler</div>
                <div className="flex items-center pt-2">
                    <div className="bg-cover bg-center w-10 h-10 rounded-full mr-3" style={ {backgroundImage: `url(${homes.agent.image.url})`}}> 
                    </div>
                    <div>
                        <p className="font-bold text-gray-900">{homes.agent.name}</p>
                        <p className="text-sm text-gray-700">{homes.agent.phone}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
        ))}
        
</>
     );
}
 
export default Test;