import Hero from "../components/frontpage/Hero";
import Info from '../components/frontpage/Info'
import SelectedListings from '../components/frontpage/SelectedListings'
import Newsletter from '../components/frontpage/Newsletter'
import SelectedAgents from "../components/frontpage/SelectedAgents";
import MobileApp from "../components/frontpage/MobileApp";

const Frontpage = () => {
    return ( <>
        <Hero/>
        <Info/>
        <SelectedListings/>
        <Newsletter/>
        <SelectedAgents/>
        <MobileApp/>
        </>
     );
}
 
export default Frontpage;