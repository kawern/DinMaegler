import { Helmet } from "react-helmet";
import RegisterForm from "../components/user/RegisterForm";

const Register = () => {
    return ( 
        <section className="md:mx-64 mb-20">
                    <Helmet><title>Opret bruger - Din Mægler</title></Helmet>
        <RegisterForm/>
        </section>
     );
}
 
export default Register;