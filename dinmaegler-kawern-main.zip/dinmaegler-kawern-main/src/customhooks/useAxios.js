import axios from 'axios';
import { useState, useEffect } from 'react';

const useAxios = (url, endpoint) => {

	const [data, setData] = useState();
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);

	useEffect(() => {
			axios(url, endpoint, {
				headers: {
				},
			})
				.then((response) => {
					if (response.status !== 200) throw new Error('Unable to fetch data for the resource');
					setData(response.data);
					setLoading(false);
					setError(null);
				})
				.catch((err) => {
					setLoading(false);
					setError(err.message);
				});
		}
    )
	return { data, loading, error };
};

export default useAxios;