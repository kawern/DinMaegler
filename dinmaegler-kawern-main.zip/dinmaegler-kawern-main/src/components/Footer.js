import logo from '../images/logo.png'
import { IoIosPaperPlane, BsTelephoneFill, MdLocationPin } from 'react-icons/all'
import { Link } from '@reach/router';

const Footer = () => {
    return ( 
        <footer className="bottom-0 md:px-64 bg-footer pt-20 p-6 flex flex-col md:block">
                        <img src={logo} alt="Din Mægler"/>
                        <p className="md:w-4/6 mt-4 mb-6">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words.</p>
                        
                        <div className="flex flex-col md:flex-row">
                        <div className="flex flex-col bg-white p-8 md:mr-40 text-lg">
    <div className="flex items-center mb-6">
      <span className="rounded-full flex justify-center items-center	bg-primary w-14 h-14 mr-4">
    <BsTelephoneFill fill="white" size={23}/>
    </span>
      <div>
        <p className="text-xs mb-2">Ring til os</p>
        <p>+45 7070 4000</p>
      </div>
    </div>
    <div className="flex items-center mb-6">
    <span className="rounded-full flex justify-center items-center	bg-primary w-14 h-14 mr-4">
    <IoIosPaperPlane fill="white" size={25}/>
    </span>
      <div>
        <p className="text-xs mb-2">Send en mail</p>
        <p>4000@dinmaegler.com</p>
      </div>
    </div>
    <div className="flex items-center mb-6">
      <span className="rounded-full flex justify-center items-center	bg-primary w-14 h-14 mr-4">
    <MdLocationPin fill="white" size={23}/>
    </span>
      <div>
        <p className="text-xs mb-2">Butik</p>
<p>Stændertorvet 78</p>
<p>4000 Roskilde</p>
      </div>
    </div>
</div>

<div>
    <h3 className="font-medium mb-4">Quick Links</h3>
    <ul className="text-lg">
        <Link to="/listings"><li className="mb-2">Boliger til salg</li></Link>
        <Link to="/agents"><li className="mb-2">Mæglere</li></Link>
        <Link to="/contact"><li className="mb-2">Kontakt os</li></Link>
        <Link to="/login"><li>Log ind / bliv bruger</li></Link>
    </ul>
    </div>
                        </div>

        </footer>
     );
}
 
export default Footer;