const LogOut = () => {
    const handleLogOut = () => {
        sessionStorage.removeItem('token')
        sessionStorage.removeItem('userID')
        sessionStorage.removeItem('homes')
        document.location.href="/";
      }
    return ( 
        <p onClick={handleLogOut}>Log ud</p>
     );
}
 
export default LogOut;