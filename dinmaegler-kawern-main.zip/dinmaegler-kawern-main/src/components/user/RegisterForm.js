import Button from "../Button";

const RegisterForm = () => {
    return ( 
        <section className=" bg-blueGray-50">
<div className="md:mx-64 pt-6">
  <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0">
    <div className="rounded-t mb-0 px-6 py-6">
      <div className="text-center mb-3">
        <h2 className="font-bold">
        Opret bruger hos Din Mægler
        </h2>
      </div>

    </div>
    <div className="flex-auto px-4 lg:mx-24 py-10 pt-0">
      <form>
        <div className="relative w-full mb-3">
          <label className="block uppercase text-xs font-bold mb-2" htmlfor="grid-password"> Fulde Navn</label>
          <input type="email" className="border-0 px-3 py-3 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" placeholder="Name"/>
        </div>

        <div className="relative w-full mb-3">
          <label className="block uppercase text-xs font-bold mb-2" htmlfor="grid-password">Email Adresse</label>
          <input type="email" className="border-0 px-3 py-3 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" placeholder="Email"/>
        </div>

        <div className="relative w-full mb-3">
          <label className="block uppercase text-xs font-bold mb-2" htmlfor="grid-password">Password</label>
          <input type="password" className="border-0 px-3 py-3 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" placeholder="Password"/>
        </div>

        <div className="text-center mt-6 text-white">
        <Button 
        color="primary"
    text="Opret Bruger"
    height="14"
    width="full"
    type="submit"
    />
        </div>
      </form>
    </div>
  </div>
</div>
</section>
     );
}
 
export default RegisterForm;