import Button from "../Button";
import axios from "axios";
import { useForm } from "react-hook-form";
import { useContext } from "react";
import { TokenContext } from "../../contexts/TokenContext";

const LoginForm = () => {

  const { setToken } = useContext(TokenContext)
  const {
    register,
    handleSubmit,
    formState: { errors },
} = useForm();



  const onSubmit = (data) => {
    axios.post('https://dinmaegler.herokuapp.com/auth/local', data)
    .then(response => {
      if(response.status === 200) {
      sessionStorage.setItem("token", response.data.jwt)
        sessionStorage.setItem("userID", response.data.user.id)
        sessionStorage.setItem("homes", JSON.stringify(response.data.user.homes))
        setToken(true)
        window.location.href="/favorites";
      }
    }
    )
  }

  return (
      <div className="pt-6">
        <div className="md:relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0">
          <div className="rounded-t mb-0 px-6 py-6">
            <div className="text-center mb-3">
              <h2 className="font-bold">Log ind på din konto</h2>
            </div>
          </div>
          <div className="flex-auto px-4 lg:mx-24 py-10 pt-0">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="relative w-full mb-3">
                <label
                htmlFor="identifier"
                  className="block uppercase text-xs font-bold mb-2"
                >
                  Email Adresse
                </label>
                <input
                  className="border-0 px-3 py-3 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  type="email"
                  name="identifier"
                  id="identifier"
                  placeholder="Ìndtast din email"
            {...register("identifier", {
              required: true,
              minLength: 6,
              pattern:
                /^(([^<>()\]\\.,;:\s@"]+(\.[^<>()\]\\.,;:\s@"]+)*)|(".+"))@(([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            })}
          />
                  {errors.identifier?.type === "required" && (
            <p className="text-xs text-red-600 mt-3">Indtast venligst din email adresse</p>
        )}
        {errors.identifier?.type === "pattern" && (
                <p className="text-xs text-red-600 mt-3">Indtast venligst en korrekt email</p>
            )}
                
              </div>

              <div className="relative w-full mb-3">
                <label
                htmlFor="password"
                  className="block uppercase text-xs font-bold mb-2"
                >
                  Password
                </label>
                <input
                  className="border-0 px-3 py-3 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  type="password"
                  name="password"
                  placeholder="Indtast din email adresse"
                  {...register("password", { required: true, minLength: 6 })}/>
                  {errors.password?.type === "required" && (
            <p className="text-xs text-red-600 mt-3">Indtast venligst dit kodeord</p>
        )}
        {errors.password?.type === "minLength" && (
            <p className="text-xs text-red-600 mt-3">Indtast venligst dit kodeord</p>
        )}
              </div>

              <div className="text-center mt-6 text-white">
                <Button
                  text="Log ind"
                  height="14"
                  width="full"
                  type="submit"
                  color="primary"
                />
              </div>
            </form>
            <div className="my-4">
              <p className="mb-4">Log ind med</p>
              <div className="flex gap-4 text-white">
                <Button
                  text="Google"
                  height="12"
                  width="1/3"
                  type="submit"
                  color="red-600"
                />
                <Button
                  text="Facebook"
                  height="14"
                  width="1/3"
                  type="submit"
                  color="blue-800"
                />
                <Button
                  text="Twitter"
                  height="14"
                  width="1/3"
                  type="submit"
                  color="primary"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

  );
};

export default LoginForm;
