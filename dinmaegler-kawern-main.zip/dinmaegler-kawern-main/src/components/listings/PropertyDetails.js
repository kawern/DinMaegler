import { useParams } from "@reach/router";
import { useEffect } from "react";
import useAxios from "../../customhooks/useAxios";

import Spinner from '../Spinner'
import PropertyTable from "./PropertyTable";

import { IoIosPaperPlane, BsTelephoneFill } from 'react-icons/all'
import IconLinks from './IconLinks'
import '@brainhubeu/react-carousel/lib/style.css';

import NumberFormat from "react-number-format";


const PropertyDetails = (props) => {

  const { id } = useParams();

  const url = `https://dinmaegler.herokuapp.com/homes/${id}`;
  const { data, loading, error } = useAxios(url);

  useEffect(() => {
    if (error) throw new Error(error);
  }, [error]);



  return loading ? (<div className="mx-64"><Spinner/></div>) : (<>
      <img className="h-96 w-full object-cover mb-4"
        src={data?.images[0].url}
        alt={data?.name}
      />
      <section className="md:mx-64">
      <div className="flex flex-col md:flex-row  justify-between items-center">
        <div className="flex flex-col text-center md:text-left">
        <div className="block mb-4 md:mb-0 md:hidden flex justify-center">
        <IconLinks props={data}/>
</div>
          <p className="text-4xl md:text-2xl font-medium">{data?.adress1}</p>
          <h4 className="font-medium text-2xl md:text-xl">
            {data?.postalcode} {data?.city}
          </h4>
        </div>
<div className="hidden md:block">
        <IconLinks props={data}/>
</div>
        <div>
          <span className="text-xl font-medium">
          <NumberFormat
        value={data?.price}
        displayType={"text"}
        thousandSeparator="."
        decimalSeparator=","
        prefix={"Kr. "}
      />
        
            </span>
        </div>
      </div>

      <div className="border-t md:my-6 my-2  border-hr">
        </div>
<PropertyTable
id={data?.id}
basement={data?.basemnentsize}
livingspace={data?.livingspace}
payment={data?.payment}
built={data?.built}
gross={data?.gross}
lotsize={data?.lotsize}
remodel={data?.remodel}
netto={data?.netto}
rooms={data?.rooms}
energylabel={data?.energylabel}
cost={data?.cost}
long={data?.long}

/>

<div className="flex flex-col md:flex-row  justify-between">
    <div className="px-6 md:px-0 md:w-2/4 text-justify">
        <h3 className="mb-4 font-medium text-center md:text-left">Beskrivelse</h3>
        <p className="mb-4">{data?.description}</p>
        </div>

    <div className="px-6 my-4 md:my-0 md:px-0 md:w-3/5 md:ml-10 text-center md:text-left">
    <h3 className="mb-4 font-medium">Ansvarlig Mægler</h3>
    <div className="border-2 p-4 flex flex-col md:flex-row items-center">
        <img className="md:w-44 md:h-44 md:mr-6 object-cover" src={data?.agent.image.url} alt={data?.agent.name}/>
        <div className="flex flex-col">
        <h3 className="font-medium mb-2">{data?.agent.name}</h3>
        <p className="text-gray-400">{data?.agent.title}</p>
        <div className="border-t mt-2 mb-6 w-11 border-gray-400"></div>
        
        <div className="flex flex-col">
        <p className="flex items-center mb-4"><BsTelephoneFill size={18} fill="primary" className="mr-4"/>
        {data?.agent.phone}</p>
        <p className="flex items-center"><IoIosPaperPlane size={20} fill="primary" className="mr-4"/> {data?.agent.email}</p>
        </div>
            </div>
    </div>
    </div>
</div>
</section>
</>
  );
};

export default PropertyDetails;
