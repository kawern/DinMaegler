import { useParams } from '@reach/router'
import useAxios from "../../customhooks/useAxios";
import PropertyCard from "./PropertyCard";
import CardSkeleton from "../CardSkeleton"
import Heading from "../Heading";

const FilteredPropertyList = (props) => {

    const params = useParams()
    const url = `https://dinmaegler.herokuapp.com/homes?type_eq=${params.type}`
    const { data, loading } = useAxios(url);

    function handleChange(value) {
        window.location.href = `/listings/types/${value}`
      }

    return loading ? (<div className="mx-64"><CardSkeleton/></div>) : (
        <section>
                    <Heading className="mx-0" title={`Boliger til salg - ${params.type}`}/>
                    <div className="md:mx-64 md:mb-20">
           <div>
     {props.noFilter ? null : (     <><p className="mb-2 flex">Ejendomstype</p>
          <select
                      id="dropdown"
                      onChange={event => handleChange(event.target.value)}
                      // onChange={(e) => window.location=`listings/${e.target.value}` & console.log(e.target.value)}
            className="flex w-52 py-2 px-3 border border-gray-300 bg-white shadow-sm"
            name="types"
          >
              <option>{params.type}</option>
              <option
              value={data?.type}>Villa</option>
<option value={data?.type}>Landejendom</option>
<option value={data?.type}>Ejerlejlighed</option>
<option value={data?.type}>Byhus</option>
<option value="../">Alle</option>
        
        </select></>)}
        </div>
            <div className="grid md:grid-cols-2 gap-4">
        {loading ? (<CardSkeleton/>) : 
        data?.map(listing => (
            
                    <PropertyCard
                    key={listing.id}
                    id={listing.id}
                    image={listing.images[0].formats.thumbnail.url}
                    address={listing.adress1}
                    city={listing.city}
                    postalcode={listing.postalcode}
                    type={listing.type}
                    cost={listing.cost}
                    energylabel={listing.energylabel}
                    rooms={listing.rooms}
                    livingspace={listing.livingspace}
                    price={listing.price}
                    />
    ))}</div>
    </div>
    </section>
     );
}
 
export default FilteredPropertyList;