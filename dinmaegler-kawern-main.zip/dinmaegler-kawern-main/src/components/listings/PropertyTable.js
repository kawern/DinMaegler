import NumberFormat from "react-number-format";

const PropertyTable = (props) => {
  return (
    <>
      <div className="flex flex-col md:flex-row justify-between mx-6 md:mx-0 mb-10 ">
        <div className="flex flex-col">
          <div className="text-center md:text-left mb-4 md:mb-0">
            <p className="inline-block w-32 font-bold md:font-normal font-bold md:font-normal">
              Sagsnummer:
            </p>
            {props.id}
          </div>
          <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-32 font-bold md:font-normal">
              Boligareal:{" "}
            </p>
            <p className="justify-end">{props.livingspace} m2</p>
          </div>
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-32 font-bold md:font-normal">
              Grundareal:{" "}
            </p>{" "}
            {props.lotsize} m2
          </div>
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-32 font-bold md:font-normal">
              Rum/Værelser:{" "}
            </p>{" "}
            {props.rooms}
          </div>
        </div>
        <div className="flex flex-col">
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-32 font-bold md:font-normal">
              Kælder:
            </p>{" "}
            {props.basementsize ? "0" : "0"} m2
          </div>
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-32 font-bold md:font-normal">
              Byggeår:{" "}
            </p>{" "}
            {props.built} m2
          </div>
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-32 font-bold md:font-normal">
              Ombygget:{" "}
            </p>{" "}
            {props.remodel} m2
          </div>
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-32 font-bold md:font-normal">
              Energimærke:{" "}
            </p>{" "}
            {props.energylabel}
          </div>
        </div>
        <div className="flex flex-col">
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-44 font-bold md:font-normal">
              Udbetaling:
            </p>
            <NumberFormat
              value={props.payment}
              displayType={"text"}
              thousandSeparator="."
              decimalSeparator=","
              prefix={"Kr. "}
            />
          </div>
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-44 font-bold md:font-normal">
              Brutto ex ejerudgift:{" "}
            </p>
            <NumberFormat
              value={props.gross}
              displayType={"text"}
              thousandSeparator="."
              decimalSeparator=","
              prefix={"Kr. "}
            />
          </div>
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-44 font-bold md:font-normal">
              Netto ex ejerudgift:{" "}
            </p>
            <NumberFormat
              value={props.netto}
              displayType={"text"}
              thousandSeparator="."
              decimalSeparator=","
              prefix={"Kr. "}
            />
          </div>
                    <div className="flex justify-between md:justify-start	">
            <p className="inline-block w-44 font-bold md:font-normal">
              Ejerudgifter:{" "}
            </p>
            <NumberFormat
              value={props.cost}
              displayType={"text"}
              thousandSeparator="."
              decimalSeparator=","
              prefix={"Kr. "}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default PropertyTable;
