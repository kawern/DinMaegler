
import useAxios from "../../customhooks/useAxios";
import PropertyCard from "./PropertyCard";
import CardSkeleton from "../CardSkeleton"

const PropertyList = (props) => {

    let endpoint = props.endpoint
    const url = endpoint ? `https://dinmaegler.herokuapp.com/homes${endpoint}` : `https://dinmaegler.herokuapp.com/homes`
    const { data, loading } = useAxios(url);

    function handleChange(value) {
      window.location.href = `/listings/types/${value}`
    }

    return (
        <>
            <div>
     {props.noFilter ? null : (     <><p className="mb-2 flex">Ejendomstype</p>
          <select
                      id="dropdown"
                      onChange={event => handleChange(event.target.value)}
                      // onChange={(e) => window.location=`listings/${e.target.value}` & console.log(e.target.value)}
            className="flex w-52 py-2 px-3 border border-gray-300 bg-white shadow-sm"
            name="types"
          >
              <option value={data}>Alle</option>
              <option
              value={data?.type}>Villa</option>
<option value={data?.type}>Landejendom</option>
<option value={data?.type}>Ejerlejlighed</option>
<option value={data?.type}>Byhus</option>
        
        </select></>)}
        </div>
            <div className="grid md:grid-cols-2 gap-4">
        {loading ? (<CardSkeleton/>) : 
        data?.map(listing => (
            
                    <PropertyCard
                    key={listing.id}
                    data={data}
                    id={listing.id}
                    image={listing.images[0].formats.thumbnail.url}
                    address={listing.adress1}
                    city={listing.city}
                    postalcode={listing.postalcode}
                    type={listing.type}
                    cost={listing.cost}
                    energylabel={listing.energylabel}
                    rooms={listing.rooms}
                    livingspace={listing.livingspace}
                    price={listing.price}
                    />
    ))}</div>
    </>
     );
}
 
export default PropertyList;