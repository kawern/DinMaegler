
import NumberFormat from "react-number-format";
import IconLinks from "./IconLinks";

const PropertyHead = (props) => {

const data = props.props

    return ( 
        <>
        
              <img
        className="h-96 max-w-screen-lg object-cover object-center mb-6"
      
      />
      <div className="flex flex-row  justify-between items-center">
        <div className="flex flex-col">
          <h4 className="font-medium">{data?.adress1}</h4>
          <h4 className="font-medium">
            {data?.postalcode} {data?.city}
          </h4>
        </div>
<IconLinks props={data}/>
        <div>
          <span className="text-xl font-medium">
          <NumberFormat
        value={data?.price}
        displayType={"text"}
        thousandSeparator="."
        decimalSeparator=","
        prefix={"Kr. "}
      />
        
            </span>
        </div>
      </div>
        </>
     );
}
 
export default PropertyHead;