import { useParams } from "@reach/router";
import { useEffect } from "react";

import useAxios from "../../customhooks/useAxios";

import Carousel from "@brainhubeu/react-carousel";
import "@brainhubeu/react-carousel/lib/style.css";

const Gallery = (props) => {

    const { id } = useParams();

    const url = `https://dinmaegler.herokuapp.com/homes/${id}`;
    const { data, error } = useAxios(url);

    useEffect(() => {
        if (error) throw new Error(error);
      }, [error]);
      
  return (
    <>
            <Carousel plugins={["arrows"]}>
              {data?.images.map(image => (
                <img
                  src={image && image.url}
                  className="object-cover"
                  alt="Billedegalleri"
                />
              ))}
            </Carousel>
    </>
  );
};

export default Gallery;
