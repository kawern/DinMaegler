const Map = () => {
  return (
    <div className="w-full h-96 mb-6">
      <iframe
      title="Find os"
height="400"
        width="100%"
        frameborder="0"
        scrolling="no"
        marginheight="0"
        marginwidth="0"
        id="gmap_canvas"
        src="https://maps.google.com/maps?width=520&amp;height=400&amp;hl=en&amp;q=Haraldsborgvej%20143%20Roskilde+(Title)&amp;t=&amp;z=13&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"
      ></iframe>
      <script
        type="text/javascript"
        src="https://embedmaps.com/google-maps-authorization/script.js?id=1826d04816ba72aa5b6133083a5d5f3c5d17fcc0"
      ></script>
    </div>
  );
};

export default Map;
