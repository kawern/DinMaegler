import AddToFavorites from "../favorites/AddToFavorites";
import { Link } from "@reach/router";
import { useContext } from "react";
import NumberFormat from "react-number-format";
import { TokenContext } from "../../contexts/TokenContext";

const PropertyCard = (props) => {

  const { token } = useContext(TokenContext)

  const data = props.data

  return (
      <div className="shadow-md">
        <div className="flex justify-end">
          { token ? 
          (<div className="absolute mr-4 mt-4">
          <AddToFavorites
          id={props.id}
          data={data}/></div>) : null }
          <Link
          className="w-full" 
          to={`/listings/${props.id}`}>
          <img
            className="w-full h-72 object-cover bg-center"
            src={props.image}
            alt={props.address}
          /></Link></div>
          <div className="p-6 text-left">
            <h4 className="mb-3 font-medium">{props.address}</h4>
            <p className="mb-3 text-md">
              {props.postalcode} {props.city}
            </p>
            <p className="text-sm mb-3">
              <span className="font-medium text-xl">{props.type} •</span> Ejerudgift: {props.cost} kr.
            </p>
            <div className="border-t my-4 border-hr">
        </div>
            <div className="flex flex-row items-center ">
              <span className={`text-md w-7 h-7 font-bold inline-block p-2 leading-3 text-white bg-green-600
              uppercase mr-4
              ${props.energylabel === "D" ? "bg-red-600" : ""}
              ${props.energylabel === "C" ? "bg-yellow-200" : ""}`}
              >
                {props.energylabel}
              </span>
              <span className="w-1/3 items-center md:leading-none text-sm  py-1 border-gray-200">
                {props.rooms} værelser • {props.livingspace} m²
              </span>
              <span className="w-2/3 items-center text-right leading-none text-xl font-medium">
              <NumberFormat
        value={props.price}
        displayType={"text"}
        thousandSeparator="."
        decimalSeparator=","
        prefix={"Kr. "}
      />
              </span>
            </div>
          </div>
        </div>
  );
};

export default PropertyCard;
