import pin from "../../images/transparent_pin.svg";
import floorplan from "../../images/layer.svg";
import gallery from '../../images/gallery.svg'
import favorites from "../../images/favorites.svg";

import Modal from "../Modal";

import Carousel from '@brainhubeu/react-carousel';
import Map from "./Map";

const IconLinks = (props) => {

  const data = props.props

  return ( 
    <div className="flex gap-8">
          <span className="w-8">
          <Modal
          icon={gallery}
          content={
                                <Carousel
                                plugins={['arrows']}
                              >
                              {data?.images.map(image => (
                                  <img src={image.url} className="object-cover" alt=""/>
                              ))}
                              </Carousel>
          }/>
          </span>
          <span className="w-8">
          <Modal
          icon={floorplan}
          content={
            <img src={data?.floorplan.url} className="w-2/3 justify-center" alt="Floorplan"/>
          }
          />
          </span>
          <span className="w-5">
          <Modal
          icon={pin}
          content={<Map/>}
          />
          </span>
          <span className="w-8">
            <img src={favorites} alt="Tilføj til favoritter" />
          </span>
        </div>
   );
}
 
export default IconLinks;