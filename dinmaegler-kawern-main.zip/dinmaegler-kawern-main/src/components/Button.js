const Button = ({icon, text, width, height, transparent, inverted, color}) => {
    return ( 
        <button
        className={`flex flex-row p-4 items-center justify-center w-${width} h-${height} rounded-sm font-medium bg-${color} text-lg
        ${transparent ? "border-white border" : ""}
        ${inverted ? " border bg-white text-primary" : ""}`}>
            {icon} {text}
        </button>
     );
}
 
export default Button;