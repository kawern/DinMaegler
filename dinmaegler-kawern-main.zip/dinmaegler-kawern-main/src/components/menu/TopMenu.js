import logo from '../../images/logo.png'
import { Link } from '@reach/router';
import { TokenContext } from "../../contexts/TokenContext";
import { useContext } from "react";

const TopMenu = () => {

    const { token } = useContext(TokenContext)


    return ( <>
        <div className="hidden lg:flex h-20 flex flex-row justify-between items-center px-64">
            <Link to="/"><img src={logo} alt="Din Mægler"/></Link>
            <ul className="flex flex-row">
                <Link to="/listings">
                    <li className="mr-6">Boliger til salg</li>
                </Link>
                <Link to="/agents">
                <li className="mr-6">Mæglere</li>
                </Link>
                {token ?
                (
                <Link to="/favorites">
                <li className="mr-6">Mine Favoritter</li>
                </Link>
                )
                : null}
                <Link to="/contact"><li>Kontakt os</li></Link>
            </ul>
        </div>
        </>
     );
}
 
export default TopMenu;