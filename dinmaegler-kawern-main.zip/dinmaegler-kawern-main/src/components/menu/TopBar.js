import { Link } from '@reach/router';
import { IoIosPaperPlane, BsTelephoneFill, FaUser } from 'react-icons/all'
import { TokenContext } from "../../contexts/TokenContext";
import { useContext } from "react";
import LogOut from '../user/LogOut';
import MobileMenu from './MobileMenu';
import logo from '../../images/logo.png'

const TopBar = () => {

    const { token } = useContext(TokenContext)

    return (<>
        <div className="lg:hidden flex justify-end">
            
        <Link to="/"><img src={logo} alt="Din Mægler"/></Link><div className="sm:ml-6 md:ml-10"><MobileMenu/></div>
        </div>
        <div className="">
<div className="hidden lg:flex h-14 bg-primary text-white md:flex-row justify-between items-center px-64 text-lg	font-normal">
<div className="flex flex-row">
<p className="mr-4"><IoIosPaperPlane size={28} fill="white" className="inline-block"/> 4000@dinmaegler.com</p>
<p><BsTelephoneFill size={22} fill="white" className="inline-block"/> +45 7070 4000</p>
</div>
<div className="flex flex-row items-center">
<FaUser size={20} fill="white" className="mr-2"/>
{token ? (
<LogOut/>
): <Link to="/login">
    <p className="cursor-pointer">Log ind</p></Link>}</div>
</div>
</div>
</>);
}
 
export default TopBar;