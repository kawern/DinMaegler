import { useState } from "react";
import { Link } from '@reach/router';
import { TokenContext } from "../../contexts/TokenContext";
import { useContext } from "react";
import { BsFillHouseFill, BsFillPersonFill, BsFillStarFill, BsFillEnvelopeFill, BsFillXCircleFill, BsFillPersonCheckFill, BsFillPersonPlusFill } from 'react-icons/all'
import LogOut from "../user/LogOut";


const MobileMenu = () => {
    const { token } = useContext(TokenContext)
    const [isOpen, setIsOpen] = useState(false);
    const HamburgerLine = `h-1 w-8 my-1 bg-white transition ease transform duration-300`;

  return (
  <>
    <button 
      className="flex flex-col  sticky top-0 bg-primary h-14 w-14  justify-center items-center"
      onClick={() => setIsOpen(!isOpen)}
    >
      <div
        className={`${HamburgerLine} ${
          isOpen
            ? "rotate-45 translate-y-3  group-hover:opacity-100"
            : " group-hover:opacity-100"
        }`}
      />
      <div
        className={`${HamburgerLine} ${
          isOpen ? "opacity-0" : " group-hover:opacity-100"
        }`}
      />
      <div
        className={`${HamburgerLine} ${
          isOpen
            ? "-rotate-45 -translate-y-3  group-hover:opacity-100"
            : " group-hover:opacity-100"
        }`}
      />
    </button>
    <div>
         {isOpen ? (
        <div className="w-full bg-primary border-white text-white">
<ul className="flex flex-col gap-1 uppercase text-xl font-bold tracking-wider">
                <Link to="/listings">
                    <li
                      onClick={() => setIsOpen(false)}
                    className="p-4 border-b gap-3 flex gap-3 items-center">
                    <BsFillHouseFill size={26}/>
                    Boliger til salg</li>
                </Link>
                <Link to="/agents">
                <li
                onClick={() => setIsOpen(false)}
                className="p-4 border-b gap-3 flex gap-3 items-center">
                    <BsFillPersonFill size={26}/> Mæglere</li>
                </Link>
                {token ?
                (
                <Link to="/favorites">
                <li
                onClick={() => setIsOpen(false)}
                className="p-4 border-b gap-3 flex gap-3 items-center">
                   <BsFillStarFill size={26}/> Mine Favoritter</li>
                </Link>
                )
                : null}
                <Link to="/contact">
                <li
                onClick={() => setIsOpen(false)}
                className="p-4 border-b gap-3 flex gap-3 items-center">
                    <BsFillEnvelopeFill size={26}/> Kontakt os</li></Link>
                    {token ? (
                    <li
                    onClick={() => setIsOpen(false)}
                    className="p-4 gap-3 flex gap-3 items-center"><BsFillXCircleFill fill="red" size={26}/> <LogOut/></li>
): (<Link to="/login">
               <li
               onClick={() => setIsOpen(false)}
               className="p-4 gap-3 flex gap-3 items-center">
                   <BsFillPersonCheckFill size={26}/> Log ind</li></Link>
)}
{token ? null : <Link to="/register">
<li
onClick={() => setIsOpen(false)}
className="p-4 gap-3 flex gap-3 items-center">
                   <BsFillPersonPlusFill size={26}/> Opret Bruger</li></Link>}
            </ul>
        </div>
    ) : null}
    </div>
    </>
  );
};

export default MobileMenu;
