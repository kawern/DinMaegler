import { Link } from "@reach/router";
import AgentList from "../agents/AgentList";
import Button from "../Button";

const SelectedAgents = () => {
    return ( 
        <div className="bg-footer py-20 px-6 md:px-64 m-auto pb-20">
        <div className="text-center text-lg mb-12">
        <h1 className="font-bold mb-6 text-center">Mød vores engagerede medarbejdere</h1>
            <p>
            Din Mægler er garant for altid veluddannet assistance i dit boligsalg.
            </p>
            <p>
            Kontakt en af vores medarbejdere.
            </p>
            </div>
<div >
            <AgentList endpoint="?_limit=3"/>
            </div>
            <div className="flex justify-center my-12 text-white">
            <Link to="/agents"><Button 
            color="primary"
    text="Se alle mæglere"
    height="14"
    width="44"
    /></Link>
    </div>
        </div>
     );
}
 
export default SelectedAgents;