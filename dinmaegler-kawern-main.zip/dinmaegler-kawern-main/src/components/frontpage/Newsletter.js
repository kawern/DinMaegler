import ArrowRight from '../../images/arrow.svg'
import { useForm } from 'react-hook-form';
import axios from 'axios';
import { useState } from 'react';


const Newsletter = () => {

  const  [subscribed, setSubscribed] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm();
  const onSubmit = (data) => {
    axios.post('https://dinmaegler.herokuapp.com/subscribers', data)
    .then(response => {
      if(response.status === 200) {
        sessionStorage.setItem("subscribed", true)
        setSubscribed(true)
        alert("Du er nu tilmeldt vores nyhedsbrev")
      }
    }
    )
  }
    return ( 
        <div className="w-full h-64 bg-newsletter bg-center">
            <div className="bg-black bg-opacity-60 h-full flex flex-col md:flex-row items-center md:px-64">

                    <h2 className="text-white text-center  md:text-left mx-10 md:mx-0 my-8 mx:mb-0 font-bold md:pr-8 md:w-1/2">Tilmeld dig vores nyhedsbrev <p className="md:inline-block hidden">og 
hold dig opdateret på boligmarkedet</p></h2>
<div className="relative flex flex-row md:pr-12">
  {subscribed ? (<p className="text-white">Du er allerede tilmeldt vores nyhedsbrev</p>) : 
<form onSubmit={handleSubmit(onSubmit)}>
<input
                  className="px-3 text-lg py-3 relative bg-white rounded border-0 shadow outline-none focus:outline-none focus:ring md:w-96 h-16"
                  type="email"
                  name="email"
                  id="email"
                  placeholder="Ìndtast din email"
            {...register("email", {
              required: true,
              minLength: 6,
              pattern:
                /^(([^<>()\]\\.,;:\s@"]+(\.[^<>()\]\\.,;:\s@"]+)*)|(".+"))@(([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            })}
            
          />
                    {errors.email?.type === "required" && (
            <p className="text-xs text-red-600 mt-3">
              Indtast venligst din email
            </p>
          )}
  <button className="h-full absolute rounded w-8 md:right-14 right-0 pr-3 py-3">
    <img src={ArrowRight} alt="Search"/>
  </button>
  </form>
}
</div>
                        
                        </div>
        </div>
     );
}
 
export default Newsletter;