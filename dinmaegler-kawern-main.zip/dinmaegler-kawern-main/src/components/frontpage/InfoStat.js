const InfoStat = ({img, alt, title, height, width, content, placement, imgWidth, imgHeight, mb, textWidth}) => {
    return (  
        <div className={`flex flex-col md:flex-row mb-4 md:mb-0 ${placement}`}>
        <span className={`bg-lightBlue w-${width} h-${height} flex self-center md:self-start justify-center items-center md:mr-4`}>
            <img src={img} className={`w-${imgWidth} h-${imgHeight}`} alt={alt}/></span>
            <div className="flex flex-col  mt-4 md:mt-0">
        <h3 className={`font-medium text-center md:text-left  text-4xl md:text-2xl mb-${mb}`}>{title}</h3>
        <p className={`text-xl md:text-base md:w-60 h-24 md:text-left`}>{content}</p>
            </div>
    </div>
    );
}
 
export default InfoStat;
