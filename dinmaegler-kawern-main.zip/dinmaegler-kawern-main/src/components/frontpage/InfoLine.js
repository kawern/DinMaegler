import InfoStat from "./InfoStat";
import customerhand from '../../images/handcustomer.svg'
import salescheck from '../../images/salescheck.svg'
import pin from '../../images/pin.svg'

const InfoLine = () => {
    return ( <>
        <div className="border-t my-12 border-hr">
        </div>
        <div className="flex flex-col md:flex-row justify-between mb-14 items-center">
        <InfoStat
                width="40 md:w-12"
                height="40 md:h-12"
                imgWidth="20 md:w-11"
                imgHeight="20 md:w-11"
                img={salescheck}
                mb="4"
                alt="hus"
                title="Bestil et salgstjek"
                content="Med et Din Mægler Salgstjek 
                bliver du opdateret på værdien 
                af din bolig."/>
                                <InfoStat
                width="40 md:w-12"
                height="40 md:h-12"
                imgWidth="20 md:w-7"
                imgHeight="20 md:w-7"
                img={pin}
                mb="4"
                alt="hus"
                title="74 butikker"
                content="Hos Din Mægler er din bolig 
                til salg i alle vores 74 butikker, som er fordelt rundt om i Danmark."/>
                                <InfoStat
                width="40 md:w-12"
                height="40 md:h-12"
                imgWidth="20 md:w-7"
                imgHeight="20 md:w-7"
                img={customerhand}
                mb="4"
                alt="hus"
                title="Tilmeld køberkartotek"
                content="Når du er tilmeldt vores køberkartotek, bliver du kontaktet inden en ny bolig bliver annonceret."
                contentWidth="w-20"/>
        </div>
        </>
     );
}
 
export default InfoLine;
