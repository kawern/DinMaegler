import infoimage from '../../images/infoimage.png'
import hand from '../../images/hand.svg'
import house from '../../images/house.svg'
import InfoLine from './InfoLine'
import InfoStat from './InfoStat'



const Info = () => {
    return ( 
        <div className="px-10 md:px-64">
        <div className="md:py-20 flex flex-col md:flex-row">
            <img className="md:w-2/5 md:h-2/5 md:mr-20 mb-6 md:mb-0" src={infoimage} alt="+38 års erfaring"/>
            <div className="flex flex-col text-center md:text-left ">
            <h1 className="md:w-4/5 font-bold mb-6">Vi har fulgt danskernes hjem i snart 4 årtier</h1>
            <p className="text-lg mb-6 md:mb-2 font-medium">
            Det synes vi siger noget om os!
            </p>
            <p className="mb-6 md:w-3/4">
            It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has normal distribution.
            </p>

            <p className="mb-8 md:w-3/4">
            It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
            </p>

            <div className="flex flex-col md:flex-row items-center md:justify-between gap-8 md:gap-0">

<div className="w-1/2 md:w-1/2">
                <InfoStat
                width="40 md:w-20"
                height="40 md:h-20"
                imgWidth="20 md:w-11"
                imgHeight="20 md:w-11"
                placement="items-center"
                img={hand}
                alt="hus i hånd"
                title="4829"
                content="boliger solgt"/></div>

<div className="w-1/2 md:w-1/2">
                <InfoStat
                width="40 md:w-20"
                height="40 md:h-20"
                imgWidth="20 md:w-11"
                imgHeight="20 md:w-11"
                placement="items-center"
                img={house}
                alt="hus"
                title="158"
                content="boliger til salg"/>
                </div>
            </div>
            </div>

        </div>
                    <InfoLine/>
                    </div>
     );
}
 
export default Info;