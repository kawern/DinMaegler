import PropertyList from "../listings/PropertyList";
import Button from "../Button";
import { Link } from "@reach/router";

const SelectedListings = () => {
    return ( 
        <div className="bg-footer py-20 px-6 md:px-64 m-auto pb-20">
            <h1 className="font-bold mb-6  text-center">Udvalgte Boliger</h1>
            <p className="md:mx-56 text-center mb-10">
            There are many variations of passages of Lorem Ipsum available but the this in majority have suffered alteration in some
            </p>
<div className="flex flex-col gap-4 mb-20">
            <PropertyList
            noFilter
            endpoint="?_limit=4"/>
            </div>
            <div className="flex justify-center text-white">
            <Link to="/listings"><Button 
            color="primary"
    text="Se alle boliger"
    height="14"
    width="44"
    filled
    /></Link>
    </div>
        </div>
     );
}
 
export default SelectedListings;