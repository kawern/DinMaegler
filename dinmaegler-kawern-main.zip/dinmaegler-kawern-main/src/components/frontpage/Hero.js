const Hero = () => {
  return (
    <div className="bg-hero bg-center h-96 text-white bg-cover">
      <div className="bg-black bg-opacity-50 h-96 font-medium flex flex-col justify-center items-center">
        <h1 className="mb-4 md:mb-8 text-center text-2xl md:text-5xl">Søg efter din drømmebolig</h1>
        <div className="bg-white rounded-md md:rounded-none h-auto font-normal w-4/5 md:w-2/4 p-8 text-black">
          <h4 className="mb-4 mx-4 md:mx-0 text-sm text-center font-bold md:text-xl">
            Søg blandt 158 boliger til salg i 74 butikker
          </h4>
          <p className="text-center text-sm md:text-md md:text-left">Hvad skal din næste bolig indeholde</p>
          <div className="flex border-2 flex-row">
            <input
              className="w-full ml-1 text-xs outline-none focus:outline-none focus:none"
              type="text"
              placeholder="Søg på fx. glaskeramisk komfur, bryggers, kælder eller lignende"
            />
            <button className="bg-grey-lightest border-grey border-l shadow hover:bg-grey-lightest ml-2">
              <span className="w-auto flex justify-end items-center text-grey p-2 hover:text-grey-darkest">
                <i className="material-icons text-xs">Søg</i>
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
