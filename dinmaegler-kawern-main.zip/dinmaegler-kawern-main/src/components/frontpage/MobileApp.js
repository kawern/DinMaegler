import { SiGoogleplay, SiApple } from 'react-icons/si'
import smartphones from '../../images/smartphones.png'
import Button from '../Button'

const MobileApp = () => {
    return ( 
        <div className="w-auto md:w-full text-center md:text-left h-full bg-primary md:flex flex-row justify-between px-6 py-10 md:py-0 md:px-64 pt-6 md:pt-24">
<div className="md:-mt-7">
    <h2 className="md:text-4xl font-bold md:w-80 mb-6 text-white">Hold dig opdateret 
på salgsprocessen</h2>
<p className="text-lg w-auto md:w-80 md:w-auto text-white text-justify md:mr-8">
Når du sælger din bolig hos Din Mægler, kommunikerer du nemt med den ansvarlige mægler eller butik med vores app. Her kan du også se statistik på interessen for din bolig i alle vores salgskanaler.
</p>

<div className="flex flex-row gap-4 mt-6 text-white">
<Button
    text="Google Play"
    icon={<SiGoogleplay  size={24} className="mr-2"/>}
    height="16"
    width="96"
    inverted
    />
                <Button
    text="Apple Store"
    icon={<SiApple  size={24} className="mr-2"/>}
    height="16"
    width="96"
transparent    />
</div></div>
<div className="hidden md:block w-full ml-6">
    <img src={smartphones} alt="Download vores APP"/>
</div>
        </div>
     );
}
 
export default MobileApp;
