import { Link } from '@reach/router';
import { MdEmail, RiLinkedinFill } from 'react-icons/all';

const AgentCard = ({
  id,
    image,
    name,
    title,
  }) => {
  
    return (
        <div className="shadow-md  text-center h-full">
          <Link to={`/agents/${id}`}>
            <img
              className="w-70 h-72 object-cover object-top"
              src={image}
              alt={`${name} - ${title}`}
            /></Link>
            <div className="p-6">
              <h4 className="mb-3 font-medium">{name}</h4>
              <p className="mb-3 text-md">
                {title}
              </p>
              <div className="flex flex-row justify-center gap-2">
                <p><MdEmail size={20} fill="color-primary" /></p>
                <p><RiLinkedinFill size={20} fill="color-primary" /></p>
            </div>
          </div>
        </div>
      
    );
  };
  
  export default AgentCard;
  