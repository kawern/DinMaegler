import { useEffect } from "react";
import useAxios from "../../customhooks/useAxios";
import AgentCard from "../agents/AgentCard";
import CardSkeleton from "../CardSkeleton"

const AgentList = (props) => {

    const endpoint = props.endpoint
	const url = `https://dinmaegler.herokuapp.com/agents${endpoint}`;
	const { data,loading, error } = useAxios(url);

	useEffect(() => {
		if (error) throw new Error(error);
	}, [error]);

    return ( <section>
        <div className="grid md:grid-cols-3 gap-8 justify-center">
        {loading ? (<CardSkeleton/>) : data?.map(data => (
            
                    <AgentCard
                    key={data.id}
                    id={data.id}
                    image={data.image.url}
                    name={data.name}
                    title={data.title}
                    phone={data.phone}
                    />
    ))}
    </div>
    </section>
     );
}
 
export default AgentList;