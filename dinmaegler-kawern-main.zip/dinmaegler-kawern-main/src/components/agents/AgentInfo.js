import { useParams } from "@reach/router";
import { useEffect } from "react";
import useAxios from "../../customhooks/useAxios";
import { IoIosPaperPlane, BsTelephoneFill, BiSearch, IoMdHeartEmpty } from 'react-icons/all'

import ContactForm from '../contact/ContactForm'
import Heading from "../Heading";
import Spinner from "../Spinner";

const AgentInfo = (props) => {

  const { id } = useParams();

  const url = `https://dinmaegler.herokuapp.com/agents/${id}`;
  const { data, loading, error } = useAxios(url);

  useEffect(() => {
    if (error) throw new Error(error);
  }, [error]);

    return loading ? <Spinner/> : ( <section className="mb-20">
                      <Heading title="Kontakt en medarbejder"/>
    <div className="md:mx-64 px-5 mx-auto flex flex-wrap">
      <div className="lg:w-3/5 md:w-1/2 md:pr-16 lg:pr-0 pr-0 border border-gray-200 h-auto md:p-6">
      <div className="flex justify-end">
          <div className="absolute mr-4 hidden md:block">
          <button
      className="hover:bg-primary hover:text-white w-10 h-10 z-auto bg-lightBlue text-primary rounded-full flex justify-center items-center">
  <IoMdHeartEmpty size={24}/>
      </button></div>
          </div>
    <div className="flex flex-col items-center md:items-start md:flex-row">
        <img className="w-52 h-52 md:mr-6 object-cover mt-4 md:mt-0 md:mb-6" src={data?.image.url} alt={data?.name}/>
        
        <div className="flex flex-col md:text-left text-center w-full">
        <h3 className="font-medium mb-2">{data?.name}</h3>
        <p className="text-gray-400">{data?.title}</p>
        
        <div className="border-t mt-2 mb-6 md:w-11 border-gray-200"></div>
        
        
        <div className="flex flex-col items-center md:items-start">
        <p className="flex items-center mb-4"><BsTelephoneFill size={18} fill="primary" className="mr-4"/>
        {data?.phone}</p>
        <p className="flex items-center"><IoIosPaperPlane size={20} fill="primary" className="mr-4"/>
        {data?.email}
        </p>
        </div>
            </div>
    </div>
    <div className="border-t my-6 block md:hidden"></div>
    <h4 className="font-medium text-center md:text-left">Om {data?.name}</h4>
        <div className="border-t-4 my-3 w-11 border-black hidden md:block"></div>
    <p className="mb-6 p-6 md:p-0 text-justify md:text-left">        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aspernatur amet modi officia itaque reprehenderit iusto deleniti, nostrum nemo minus libero temporibus dignissimos dolor commodi illo consectetur veniam ex necessitatibus nesciunt magnam nulla odit quidem sit? Officia voluptatem laboriosam ab harum molestias at ducimus sapiente quas repellat! Aperiam distinctio quasi id?</p>

    <div className="p-6 w-full md:w-auto border-t md:border-gray-200 md:border rounded-sm mr-6 mt-4">
      <ContactForm
      noNewsletter/>
    </div>
      </div>
      <div className="flex flex-col md:gap-y-6 md:w-1/3">
      <div className=" bg-lightBlue p-6 flex flex-col my-6 md:my-0 md:ml-6 h-auto w-full">
<h4 className="font-medium">Search property</h4>
<div className="border-t mt-2 mb-4 border-gray-400"></div>
<div className="relative flex flex-row">
  <input type="text" placeholder="Search" className="px-3 rounded-sm text-lg py-3 relative bg-white border-0 shadow outline-none focus:outline-none focus:ring w-full h-10 pl-8"/>
  <button className="h-full rounded-sm absolute w-8 mx-3 left-0">
    <BiSearch/>
  </button>
</div>
      </div>
      <div className="bg-primary text-white p-6 flex flex-col md:ml-6 md:py-24 h-auto w-full flex text-center justify-center">
<h2>Find The Best Property</h2>
<h2>For Rent Or Buy</h2>
<div className="border-t-4 my-4 mx-auto w-20 border-gray-400"></div>
<p className="text-lg">Call Us Now</p>
<h2>+00 123 456 789</h2>
      </div>
    </div>
    </div>
  </section> );
}
 
export default AgentInfo;