import axios from "axios";
import { useContext } from "react";
import { TokenContext } from "../../contexts/TokenContext";

import { IoMdHeartEmpty } from "react-icons/io";


const AddToFavorites = (props) => {

    const { token } = useContext(TokenContext)
    const userID = sessionStorage.getItem("userID")

    const homeID = props.id

    

    const addToFavorites = async () => {
      if (token) {

        const options = {
          method: 'PUT',
          url: `https://dinmaegler.herokuapp.com/users/${userID}`,
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYxNjNmOWZkZjcwOWJmMjlhYzUzMjg5NyIsImlhdCI6MTYzNTg0MDI5NSwiZXhwIjoxNjM4NDMyMjk1fQ.E2JoSn8pSiVEsh3-31kHqgz3jJMR6q4dRUQdjGwNiqA'
          },
          data: {homes: [homeID]}
        };
        
        axios.request(options).then(function (response) {
          console.log(response.data);
        }).catch(function (error) {
          console.error(error);
        });}
        }
      
    return (
      <button
      onClick={addToFavorites}
      className="hover:bg-primary hover:text-white w-10 h-10 z-auto bg-white text-primary rounded-full flex justify-center items-center">
  <IoMdHeartEmpty size={24}/>
      </button> );
}
 
export default AddToFavorites;