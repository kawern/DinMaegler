import { Link } from "@reach/router";
import axios from "axios";
import { useContext, useEffect } from "react";
import NumberFormat from "react-number-format";
import { TokenContext } from "../../contexts/TokenContext"
import useAxios from "../../customhooks/useAxios";
import CardSkeleton from "../CardSkeleton";

const FavoriteCard = (props) => {

  const { token } = useContext(TokenContext);
  const url = `https://dinmaegler.herokuapp.com/homes/${props.id}`;
  const { data, error, loading } = useAxios(url);


  useEffect(() => {
    if (error) throw new Error(error);
  }, [error]);

  const handleSubmit = async () => {
    if (token) {
      axios(`https://dinmaegler.herokuapp.com/favorites/${props}`, {
            headers: {
              Authorization: "Bearer " + token,
            }
          })
    }
    }

  return loading ? <CardSkeleton/> : data ? (
      <div className="bg-white mx-6 md:mx-0 text-center md:text-left md:h-50 border border-gray-200 rounded-sm flex flex-col md:flex-row items-center">
        <Link className="md:w-2/5" to={`/listings/${data.id}`}>
          <img
            className="p-6 object-cover bg-center"
            src={data.images[0].formats.thumbnail.url}
            alt={data.adress1}
          /></Link>
          <div className="w-full flex flex-col md:flex-row justify-between md:pr-6">
            <div className="flex flex-col">
            <h4 className="mb-3 font-medium">{data.adress1}</h4>
            <p className="mb-3 text-md">
              {data.postalcode} {data.city}
            </p>
            <p className="text-sm mb-3">
              <span className="font-medium text-xl">{data.type} </span>
              <p className="inline-block">• Ejerudgift: {data.cost} kr.</p>
            </p></div>
            <div className="border-t my-4 border-hr">
        </div>
        <div className="flex flex-col">
            <div className="flex flex-col md:flex-row md:items-center mx-6 md:mx-0">
              <span className={`text-md font-bold inline-block p-2 leading-3 text-white bg-green-600
              uppercase md:mr-4
              ${data.energylabel === "D" ? "bg-red-600" : ""}
              ${data.energylabel === "C" ? "bg-yellow-200" : ""}`}
              >
                {data.energylabel}
              </span>
              <span className="items-center md:mr-20 leading-none text-sm  py-1 border-gray-200">
                {data.rooms} værelser • {data.livingspace} m²
              </span>
              <span className="items-center md:text-right leading-none text-xl font-medium">
              <NumberFormat
        value={data.price}
        displayType={"text"}
        thousandSeparator="."
        decimalSeparator=","
        prefix={"Kr. "}
      />
              </span>
              </div>
              <div className="self-end mt-12 text-white text-xs">
              <button
    onClick={handleSubmit}
    className="hover:bg-primary hover:text-white w-10 h-10 z-auto bg-white text-primary rounded-full flex justify-center items-center">
delete
    </button></div>
            </div>
          </div>
        </div>
  ) : null ;
};

export default FavoriteCard;
