import { useEffect, useContext } from "react";
import { TokenContext } from "../../contexts/TokenContext";
import useAxios from "../../customhooks/useAxios";
import ErrorPage from "../../views/ErrorPage";
import FavoriteCard from "./FavoriteCard";
import AddToFavorites from "./AddToFavorites";
import CardSkeleton from "../CardSkeleton";

const FavoriteList = (props) => {
  const { token } = useContext(TokenContext);
  const url = `https://dinmaegler.herokuapp.com/users/me`;
  const headers = {
    headers: {
      Authorization: "Bearer " +  token,
    }
  }
  const { data, error, loading } = useAxios(url, headers);

  useEffect(() => {
    if (error) throw new Error(error);
  }, [error]);

  return loading ? <CardSkeleton/> : token ? (
    <>
    <div className="hidden"><AddToFavorites testData={data}/></div>
    
    { data?.homes.map(favorite => (
                <FavoriteCard
                key={favorite}
                id={favorite}
                />
))}
</>
  ) : <ErrorPage/>
};

export default FavoriteList;
