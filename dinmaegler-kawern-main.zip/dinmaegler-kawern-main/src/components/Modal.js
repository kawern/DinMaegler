import { useState } from 'react'


const Modal = (props) => {

  const [showModal, setShowModal] = useState(false);
  return (     <>

<img
src={props.icon}
className="cursor-pointer"
alt="Åben galleriet"
onClick={() => setShowModal(true)}/>

{showModal ? (
        <>
          <div
            className="max-h-4/5 w-full overflow-x-hidden overflow-y-hidden fixed inset-0 z-50"
          >
            <div className="relative w-auto mx-auto max-w-5xl">
              {/*content*/}
              <div className=" w-full border-0 rounded-lg shadow-lg relative flex flex-col items-center outline-none focus:outline-none px-10">
                {/*body*/}
{props.content}
                 
                {/*footer*/}
                <div className="flex justify-end border-solid border-blueGray-200 rounded-md">
                  <p 
                    className="animate-bounce text-white background-transparent font-bold uppercase px-6 py-2 text-mdoutline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-250 cursor-pointer"
                    onClick={() => setShowModal(false)}
                  >
                    Close
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div
                              onClick={() => setShowModal(false)}
          className="opacity-90 cursor-pointer w-full h-full fixed inset-0 z-40 bg-black"></div>
        </>
      ) : null}
    </>
  );
}

 
export default Modal;