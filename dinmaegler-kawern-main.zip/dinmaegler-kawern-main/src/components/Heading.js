const Heading = (props) => {
  return (
    <div className="w-full mx-0 bg-properties bg-cover mb-14">
      <div className="bg-primary mx-0 bg-opacity-80 h-20 md:h-36 flex items-center justify-center">
          <h1 className="text-center text-4xl md:text-6xl text-white font-bold">{props.title}</h1>
      </div>
    </div>
  );
};

export default Heading;
