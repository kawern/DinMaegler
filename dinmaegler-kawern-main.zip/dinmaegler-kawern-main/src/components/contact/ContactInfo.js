import { IoIosPaperPlane, BsTelephoneFill, MdLocationPin } from 'react-icons/all'
const ContactInfo = () => {
    return ( 
        <div className="flex flex-row justify-center mt-7">
        <div className="flex flex-col bg-white w-full text-lg gap-2">

        <div className="flex flex-col text-center items-center">
          <span className="rounded-full flex justify-center items-center	bg-primary w-14 h-14 mb-2">
        <BsTelephoneFill fill="white" size={23}/>
        </span>
          <div>
          <p className="font-medium mb-2">Ring til os</p>
            <p>+45 7070 4000</p>
          </div>
        </div>
        <div className="border-t m-6 border-hr">
        </div>

        <div className="flex flex-col text-center items-center ">
          <span className="rounded-full flex justify-center items-center	bg-primary w-14 h-14">
        <IoIosPaperPlane fill="white" size={25}/>
        </span>
          <div>
          <p className="font-medium mb-2">Send en mail</p>
            <p>4000@dinmaegler.com</p>
          </div>
        </div>
        <div className="border-t m-6 border-hr">
        </div>
        <div className="flex flex-col text-center items-center ">
          <span className="rounded-full flex justify-center items-center	bg-primary w-14 h-14 mb-2">
        <MdLocationPin fill="white" size={25}/>
        </span>
          <div>
            <p className="font-medium mb-2">Besøg Butikken</p>
        <p>Stændertorvet 78</p>
        <p>4000 Roskilde</p>
          </div>
        </div>
    </div>
    </div>
     );
}
 
export default ContactInfo;