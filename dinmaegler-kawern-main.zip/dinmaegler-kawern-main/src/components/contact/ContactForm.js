import { useForm } from "react-hook-form";
import Button from "../Button";

const Contactform = ({ noNewsletter }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = (data) => console.log(data);

  return (
    <form className="w-full" onSubmit={handleSubmit(onSubmit)}>
      <div className="flex flex-wrap -mx-3 mb-6">
        <div className="w-full md:w-1/2 px-3 mb-6 md:mb-0">
          <label
            className="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
            for="grid-first-name"
          >
            Navn
          </label>
          <input
            className="border-0 px-3 py-3 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
            type="text"
            name="name"
            id="name"
            placeholder="Indtast dit navn"
            {...register("name", { required: true, minLength: 6 })}
          />
          {errors.name?.type === "required" && (
            <p className="text-xs text-red-600 mt-3">
              Indtast venligst dit navn
            </p>
          )}
        </div>

        <div className="w-full md:w-1/2 px-3">
          <label className="block uppercase tracking-wide text-gray-70z0 text-xs font-bold mb-2">
            Email
          </label>
          <input
            className="border-0 px-3 py-3 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
            type="email"
            name="email"
            id="email"
            placeholder="Ìndtast din email"
            {...register("email", {
              required: true,
              minLength: 6,
              pattern:
                /^(([^<>()\]\\.,;:\s@"]+(\.[^<>()\]\\.,;:\s@"]+)*)|(".+"))@(([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            })}
          />
          {errors.email?.type === "required" && (
            <p className="text-xs text-red-600 mt-3 mt-3">
              Indtast venligst din email
            </p>
          )}
          {errors.email?.type === "pattern" && (
            <p className="text-xs text-red-600 mt-3">
              Indtast venligst en korrekt email
            </p>
          )}
        </div>
      </div>
      <div className="flex flex-wrap -mx-3 mb-6">
        <div className="w-full px-3">
          <label
            className="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
            for="grid-password"
          >
            Emne
          </label>
          <input
            className="border-0 px-3 py-3 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
            type="text"
            name="topic"
            id="topic"
            placeholder="Hvad drejer din henvendelse sig om?"
            {...register("topic", { required: true, minLength: 6 })}
          />
          {errors.topic?.type === "required" && (
            <p className="text-xs text-red-600 mt-3">
              Indtast venligst et emne
            </p>
          )}
        </div>
      </div>
      <div className="flex flex-wrap -mx-3 mb-6">
        <div className="w-full px-3">
          <label
            className="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
            for="grid-password"
          >
            Besked
          </label>
          <textarea
            className="border-0 block h-40 px-3 py-3 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
            type="text"
            name="message"
            id="message"
            placeholder="Skriv din besked her..."
            {...register("message", { required: true, minLength: 6 })}
          ></textarea>
          {errors.message?.type === "required" && (
            <p className="text-xs text-red-600 mt-3">
              Indtast venligst din besked
            </p>
          )}
        </div>
        <label
          className={`ml-4 my-4 items-center ${noNewsletter ? "hidden" : "block"}`}
        >
          <input
            type="checkbox"
            className="border-0 px-3 py-3 h-4 w-4 placeholder-blueGray-300 bg-white rounded text-sm shadow focus:outline-none focus:ring ease-linear transition-all duration-150"
          />
          <span className="ml-2 text-sm">
            Ja tak, jeg vil gerne modtage Din Mæglers nyhedsbrev.
          </span>
        </label>
      </div>
      <div className="md:flex md:items-center">
        <div className="md:w-1/3 text-white">
          <Button
            color="primary"
            text="Send besked"
            height="14"
            width="44"
            type="submit"
          />
        </div>
        <div className="md:w-2/3"></div>
      </div>
    </form>
  );
};

export default Contactform;
