const ContactMap = () => {
    return ( 
        <div className="w-full">
      <iframe
      title="Map"
height="500"
        width="100%"
        frameborder="0"
        scrolling="no"
        marginheight="0"
        marginwidth="0"
        id="gmap_canvas"
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2251.7535234062802!2d12.079433815926196!3d55.6411018805236!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46525fda9f0b4643%3A0x549b2298c1413409!2sSt%C3%A6ndertorvet%2078%2C%204000%20Roskilde!5e0!3m2!1sen!2sdk!4v1636713263959!5m2!1sen!2sdk"
      ></iframe>
      <script
        type="text/javascript"
        src="https://embedmaps.com/google-maps-authorization/script.js?id=1826d04816ba72aa5b6133083a5d5f3c5d17fcc0"
      ></script>
    </div>
     );
}
 
export default ContactMap;