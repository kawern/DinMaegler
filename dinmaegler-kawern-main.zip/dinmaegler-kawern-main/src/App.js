import './App.css';
import { Router } from '@reach/router'
import Frontpage from './views/Frontpage'

import Listings from './views/Listings';
import ListingDetails from './views/ListingDetails';
import Agents from './views/Agents';
import Register from './views/Register';
import Contact from './views/Contact'
import Favorites from './views/Favorites'
import Login from './views/Login';
import AgentDetails from './views/AgentDetails'
import Test from './views/Test'


import TopBar from './components/menu/TopBar';
import TopMenu from './components/menu/TopMenu';
import Footer from './components/Footer';

import TokenContextProvider from "./contexts/TokenContext";
import ErrorPage from './views/ErrorPage';
import FilteredPropertyList from './components/listings/FilteredPropertyList';
import { Helmet } from 'react-helmet';


function App() {

  return (<>
          <Helmet><title>Din Mægler</title></Helmet>
        <TokenContextProvider>
    <TopBar/>
    <TopMenu/>
<Router>
<ErrorPage path="/404"/>
<Test path="/test"/>
  <Frontpage path="/"/>
  <Listings path="/listings"/>
  <FilteredPropertyList path="/listings/types/:type"/>
  <ListingDetails path="/listings/:id" className="mx-0"/>
  <Agents path="/agents"/>
  <AgentDetails path="/agents/:id"/>
<Favorites path="/favorites"/>
  <Contact path="/contact"/>
  <Register path="/register"/>
  <Login path="/login"/>
</Router>
<Footer/>
</TokenContextProvider>
</>
  );
}

export default App;
